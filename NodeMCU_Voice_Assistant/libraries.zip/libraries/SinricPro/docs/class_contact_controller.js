var class_contact_controller =
[
    [ "sendContactEvent", "class_contact_controller.html#a0b4b9006c0be003c615848bcc2b690fd", null ]
];