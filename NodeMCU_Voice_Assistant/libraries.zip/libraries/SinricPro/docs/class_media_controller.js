var class_media_controller =
[
    [ "MediaControlCallback", "class_media_controller.html#a9e92d9efafd5313ef1b056030655c526", null ],
    [ "onMediaControl", "class_media_controller.html#afc2620621377fff928737b5a8a537020", null ],
    [ "sendMediaControlEvent", "class_media_controller.html#af69dc08522c75d484deab14beafcd176", null ]
];