var class_channel_controller =
[
    [ "ChangeChannelCallback", "class_channel_controller.html#a8bc108630d532266ae36cda5ec7b4857", null ],
    [ "ChangeChannelNumberCallback", "class_channel_controller.html#ab21b05b6f4a6be7e89a7173b7fafb552", null ],
    [ "SkipChannelsCallback", "class_channel_controller.html#a434616b976d1339be63540d16977fa3d", null ],
    [ "onChangeChannel", "class_channel_controller.html#a92f3b83744b5bb82d32628eef39c1eb9", null ],
    [ "onChangeChannelNumber", "class_channel_controller.html#afd8aee20590bfadec181c6ee515125ec", null ],
    [ "onSkipChannels", "class_channel_controller.html#ab1123d03d471fad4896eb2960ed41855", null ],
    [ "sendChangeChannelEvent", "class_channel_controller.html#aa85e049284116b157e34159624680ae1", null ]
];