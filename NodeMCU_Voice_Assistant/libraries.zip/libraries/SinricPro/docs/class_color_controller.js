var class_color_controller =
[
    [ "ColorCallback", "class_color_controller.html#ad8bcf09f6da3f41fffb001868cd3f84e", null ],
    [ "onColor", "class_color_controller.html#a059ff103149869b7c49cdb8911875b7b", null ],
    [ "sendColorEvent", "class_color_controller.html#aa3019d161b320267666cdb11d1c3d827", null ]
];